// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

//my_exception custom excpetion class, derived from std::excpetion
class my_exception : public std::exception
{
    //make what accessbiel and make it return the string
public:
    virtual const char* what() const throw()
    {
        return("my_excpetion was triggered \n");
    }
} myex; 

bool do_even_more_custom_application_logic()
{
    // TODO: Throw any standard exception
    //throw exception
    std::cout << "Running Even More Custom Application Logic." << std::endl;
    throw std::exception("exception in do_even_more_custom_application_logic triggered \n");

    return true;
}
void do_custom_application_logic()
{
    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing
    std::cout << "Running Custom Application Logic." << std::endl;
    //try catch block to catch excpetion
    try {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (std::exception const& e)
    {
        std::cout << e.what();
    }

    // TODO: Throw a custom exception derived from std::exception
    //  and catch it explictly in main

    throw std::exception("exception in do_custom_application_logic triggered");

    std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception

    //if denominator is 0, throw an excpetion
    if (den != 0)
        return num / den;
    else {
        throw std::exception("Attempting to divide by 0 \n");
    }
}

void do_division() noexcept
{
    //  TODO: create an exception handler to capture ONLY the exception thrown
    //  by divide.

    float numerator = 10.0f;
    float denominator = 0;
    //try catch block to catch divide exception
    try {
    auto result = divide(numerator, denominator);
    }
    catch (std::exception const &e) {
        std::cout << e.what();
    }

    int result = 1;
    std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
}

int main()
{
    //wrap main in try catch block as per instructions
    try {
        std::cout << "Exceptions Tests!" << std::endl;

        // TODO: Create exception handlers that catch (in this order):
        //  your custom exception
        //  std::exception
        //  uncaught exception 
        //  that wraps the whole main function, and displays a message to the console.

        // try catch block for custom excpetion
        try {
            throw myex;
        }
        catch (my_exception const& e) {
            //print the excpetion string
            std::cout << e.what();
        }

        do_division();
        do_custom_application_logic();
    }
    catch (std::exception const& e)
    {
        std::cout << e.what();
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu